#ifndef GLOBAL_H
#define GLOBAL_H

#include <sdl.h>

#include "SdlApplication.h"
#include "Main.h"

#endif
