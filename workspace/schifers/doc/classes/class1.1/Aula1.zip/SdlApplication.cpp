#include "Global.h"

void SdlApplication::Run()
{
	// SDL initialization

	// Game initialization
	this->Start();

	// Main Loop
	while(true)
	{
		this->Loop();
	}

	// Game finalization
	this->End();

	// SDL finalization

}
