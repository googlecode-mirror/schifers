#ifndef SDLAPPLICATION_H
#define SDLAPPLICATION_H

class SdlApplication
{
    public:
        // execution
        void Run();

        // initialize game objects
        virtual void Start() = 0;

        // main loop
        virtual void Loop() = 0;

        // free game objects
        virtual void End() = 0;
};

#endif
