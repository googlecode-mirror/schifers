#include "Global.h"

void Game::Start()
{
}

void Game::Loop()
{
}

void Game::End()
{
}

int main(int argc, char **argv)
{
	Game* game;

	game = new Game();

	game->Run();

	delete game;

	return 0;
}
