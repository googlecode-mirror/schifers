#include "Global.h"

void Game::Start()
{
    this->pImage = new Surface();

    this->pImage->LoadFromFile("natal.bmp");
}

bool Game::Loop()
{
    Message* msg = this->pInput->PopMessage();
    while(msg)
    {
        if(msg->GetType() == MSG_EXIT)
        {
            return false;
        }

        msg = this->pInput->PopMessage();
    }

    this->pImage->Blit(this->pScreen);

    return true;
}

void Game::End()
{
    this->pImage->FreeSurface();

    delete this->pImage;
}

int main(int argc, char **argv)
{
	Game* game;

	game = new Game();

	game->Run();

	delete game;

	return 0;
}
