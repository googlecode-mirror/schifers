#include "Global.h"

Message::Message()
{
  iType = 0;
}

Message::~Message()
{
}

int Message::GetType()
{
  return iType;
}

void Message::SetType(int type)
{
  iType = type;
}

LPARAM Message::GetLParam()
{
  return lParam;
}

void Message::SetLParam(LPARAM lparam)
{
  lParam = lparam;
}

WPARAM Message::GetWParam()
{
  return wParam;
}

void Message::SetWParam(WPARAM wparam)
{
  wParam = wparam;
}

void* Message::GetData()
{
  return pData;
}

void Message::SetData(void* data)
{
  pData = data;
}
