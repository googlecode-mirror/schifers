#ifndef MESSAGE_H
#define MESSAGE_H

class Message
{
  private:
    int iType;
    WPARAM wParam;
    LPARAM lParam;
    void* pData;
  public:
    Message();
    ~Message();

    int GetType();
    void SetType(int type);
    LPARAM GetLParam();
    void SetLParam(LPARAM lparam);
    WPARAM GetWParam();
    void SetWParam(WPARAM wparam);
    void* GetData();
    void SetData(void* data);
};

#endif // MESSAGE_H
