#include "Global.h"

void SdlApplication::Run()
{
	// SDL initialization
    putenv("SDL_VIDEO_WINDOW_POS");
    putenv("SDL_VIDEO_CENTERED=1");

    if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
    {
		exit(1);
    }

    SDL_WM_SetCaption("Teste", "Teste");

    this->pScreen = SDL_SetVideoMode( 800, 600, 0, SDL_HWSURFACE | SDL_DOUBLEBUF | SDL_HWACCEL );

	this->pEvent = new SDL_Event();

    this->pInput = new Input();

	// Game initialization
	this->Start();

	// Main Loop
	while(true)
	{
        this->GenerateInput();

        SDL_FillRect(this->pScreen, NULL, SDL_MapRGB( this->pScreen->format, 0, 0, 0));

		if(!this->Loop())
		{
		    break;
		}

        SDL_UpdateRect(this->pScreen, 0, 0, 0, 0);
	}

	// Game finalization
	this->End();

    delete this->pInput;

	// SDL finalization
    delete this->pEvent;

    SDL_Quit();
}

void SdlApplication::GenerateInput()
{
    if(SDL_PollEvent(this->pEvent))
    {
        if(this->pEvent->type == SDL_QUIT)
        {
            this->pMessage = new Message();

            this->pMessage->SetType(MSG_EXIT);

            this->pInput->GetDeque()->push_front(this->pMessage);
        }
        if(this->pEvent->type == SDL_KEYDOWN)
        {
            if(this->pEvent->key.keysym.sym == SDLK_ESCAPE)
            {
                SDL_Event quit;
                quit.type = SDL_QUIT;
                SDL_PushEvent(&quit);
            }
        }
    }
}
