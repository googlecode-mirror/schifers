#include "Global.h"

Surface::Surface()
{
  m_pSurface = 0;
  m_X = 0;
  m_Y = 0;
}

Surface::~Surface()
{
  m_pSurface = 0;
}

SDL_Surface* Surface::GetSurface()
{
  return m_pSurface;
}

int Surface::GetWidth()
{
  return m_Width;
}

void Surface::SetWidth(int w)
{
  m_Width = w;
}

int Surface::GetHeight()
{
  return m_Height;
}

void Surface::SetHeight(int h)
{
  m_Height = h;
}

int Surface::GetX()
{
  return m_X;
}

void Surface::SetX(int x)
{
  m_X = x;
}

int Surface::GetY()
{
  return m_Y;
}

void Surface::SetY(int y)
{
  m_Y = y;
}

void Surface::LoadFromFile(char *filename)
{
  m_pSurface = SDL_LoadBMP(filename);
  m_Width = m_pSurface->w;
  m_Height = m_pSurface->h;
}

void Surface::Blit(SDL_Surface* screen)
{
  SDL_Rect rect;
  rect.x = m_X;
  rect.y = m_Y;
  SDL_BlitSurface(m_pSurface, NULL, screen, &rect);
}

void Surface::SetTransparent()
{
  int key;

  key = SDL_MapRGB(m_pSurface->format, 255, 0, 255);

  SDL_SetColorKey(m_pSurface, SDL_SRCCOLORKEY, key);
}

void Surface::FreeSurface()
{
  SDL_FreeSurface(m_pSurface);
  m_pSurface = 0;
}

