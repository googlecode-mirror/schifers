#ifndef SURFACE_H
#define SURFACE_H

class Surface
{
  private:
    SDL_Surface* m_pSurface;
    int m_Width;
    int m_Height;
    int m_X;
    int m_Y;
  public:
    Surface();
    ~Surface();

    SDL_Surface* GetSurface();

    int GetWidth();
    void SetWidth(int w);
    int GetHeight();
    void SetHeight(int h);
    int GetX();
    void SetX(int x);
    int GetY();
    void SetY(int y);

    void LoadFromFile(char *filename);

    // Blit on the screen on position 0, 0
    void Blit(SDL_Surface* screen);

    void SetTransparent();
    void FreeSurface();
};

#endif
