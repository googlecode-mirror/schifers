#ifndef MAIN_H
#define MAIN_H

class Game : public SdlApplication
{
    public:
        void Start();
        void Loop();
        void End();
};

#endif
