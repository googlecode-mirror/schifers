#include "Global.h"

void SdlApplication::Run()
{
	// SDL initialization
    putenv("SDL_VIDEO_WINDOW_POS");
    putenv("SDL_VIDEO_CENTERED=1");

    if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
    {
		exit(1);
    }

    SDL_WM_SetCaption("Teste", "Teste");

    this->pScreen = SDL_SetVideoMode( 800, 600, 0, SDL_HWSURFACE | SDL_DOUBLEBUF | SDL_HWACCEL );

	this->pEvent = new SDL_Event();

	// Game initialization
	this->Start();

	// Main Loop
	while(true)
	{
        while(SDL_PollEvent(this->pEvent))
        {
            if(this->pEvent->type == SDL_QUIT)
            {
                break;
            }
            if(this->pEvent->type == SDL_KEYDOWN)
            {
                if(this->pEvent->key.keysym.sym == SDLK_ESCAPE)
                {
                    SDL_Event quit;
                    quit.type = SDL_QUIT;
                    SDL_PushEvent(&quit);
                }
            }
        }

		this->Loop();
	}

	// Game finalization
	this->End();

	// SDL finalization
    delete this->pEvent;

    SDL_Quit();
}
