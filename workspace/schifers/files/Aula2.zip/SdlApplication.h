#ifndef SDLAPPLICATION_H
#define SDLAPPLICATION_H

class SdlApplication
{
    private:
		SDL_Surface* pScreen;
		SDL_Event* pEvent;
	public:
        // execution
        void Run();

        // initialize game objects
        virtual void Start() = 0;

        // main loop
        virtual void Loop() = 0;

        // free game objects
        virtual void End() = 0;
};

#endif
