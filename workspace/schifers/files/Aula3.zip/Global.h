#ifndef GLOBAL_H
#define GLOBAL_H

#include <deque>

#include <sdl/sdl.h>

using namespace std;

typedef unsigned int    WPARAM;   // A type definition for the first message parameter.
typedef unsigned long   LPARAM;   // A type definition for the second message parameter.

#define MSG_EXIT 1

#include "Message.h"
#include "Input.h"
#include "Surface.h"
#include "SdlApplication.h"
#include "Main.h"

#endif
