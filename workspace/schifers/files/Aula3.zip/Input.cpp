#include "Global.h"

Input::Input()
{
}

Input::~Input()
{
}

deque<Message*>* Input::GetDeque()
{
    return &this->dqMessage;
}

Message* Input::PopMessage()
{
    if(this->dqMessage.size() > 0)
    {
        Message* message = this->dqMessage.back();
        this->dqMessage.pop_back();
        return message;
    }
    else
    {
        return 0;
    }
}
