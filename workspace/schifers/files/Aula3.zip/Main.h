#ifndef MAIN_H
#define MAIN_H

class Game : public SdlApplication
{
    private:
        Surface* pImage;
    public:
        void Start();
        bool Loop();
        void End();
};

#endif
