#include "Global.h"

Message::Message()
{
  this->iType = 0;
  this->pData = 0;
  this->wParam = 0;
  this->lParam = 0;
}

Message::~Message()
{
    this->pData = 0;
}

int Message::GetType()
{
  return this->iType;
}

void Message::SetType(int type)
{
  this->iType = type;
}

LPARAM Message::GetLParam()
{
  return this->lParam;
}

void Message::SetLParam(LPARAM lparam)
{
  this->lParam = lparam;
}

WPARAM Message::GetWParam()
{
  return this->wParam;
}

void Message::SetWParam(WPARAM wparam)
{
  this->wParam = wparam;
}

void* Message::GetData()
{
  return this->pData;
}

void Message::SetData(void* data)
{
  this->pData = data;
}
