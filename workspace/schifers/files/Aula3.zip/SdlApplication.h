#ifndef SDLAPPLICATION_H
#define SDLAPPLICATION_H

class SdlApplication
{
    private:
        SDL_Event* pEvent;
	protected:
        Input* pInput;
        Message* pMessage;
    public:
		SDL_Surface* pScreen;

        // execution
        void Run();
        void GenerateInput();

        // initialize game objects
        virtual void Start() = 0;

        // main loop
        virtual bool Loop() = 0;

        // free game objects
        virtual void End() = 0;
};

#endif
