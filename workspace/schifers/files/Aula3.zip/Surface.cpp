#include "Global.h"

Surface::Surface()
{
  this->pSurface = 0;
  this->iX = 0;
  this->iY = 0;
  this->iWidth = 0;
  this->iHeight = 0;
}

Surface::~Surface()
{
  this->pSurface = 0;
}

SDL_Surface* Surface::GetSurface()
{
  return this->pSurface;
}

int Surface::GetWidth()
{
  return this->iWidth;
}

void Surface::SetWidth(int w)
{
  this->iWidth = w;
}

int Surface::GetHeight()
{
  return this->iHeight;
}

void Surface::SetHeight(int h)
{
  this->iHeight = h;
}

int Surface::GetX()
{
  return this->iX;
}

void Surface::SetX(int x)
{
  this->iX = x;
}

int Surface::GetY()
{
  return this->iY;
}

void Surface::SetY(int y)
{
  this->iY = y;
}

void Surface::LoadFromFile(char *filename)
{
  this->pSurface = SDL_LoadBMP(filename);
  this->iWidth = this->pSurface->w;
  this->iHeight = this->pSurface->h;
}

void Surface::Blit(SDL_Surface* screen)
{
  SDL_Rect rect;
  rect.x = this->iX;
  rect.y = this->iY;
  SDL_BlitSurface(this->pSurface, NULL, screen, &rect);
}

void Surface::SetTransparent()
{
  int key;

  key = SDL_MapRGB(this->pSurface->format, 255, 0, 255);

  SDL_SetColorKey(this->pSurface, SDL_SRCCOLORKEY, key);
}

void Surface::FreeSurface()
{
  SDL_FreeSurface(this->pSurface);
  this->pSurface = 0;
}
