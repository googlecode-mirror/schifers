/****************************************************************************
 *
 *  SCHIFER TECNOLOGIA LTDA
 *
 *  EMPACOTADOR DE ARQUIVOS - VERS�O PRELIMINAR
 *
 *  Esse programa cria um arquivo de pacote para guardar os recursos de um
 *  jogo.
 *
 *  Criado por Bruno Schifer Bernardi
 *
 *  Pertence a SCHIFER TECNOLOGIA LTDA - 2008
 *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#include "bzlib.h"

#define BZ_NO_STDIO

#define FILE_HEADER_STRING "SCH"
#define MAX_FILENAME_SIZE 100

#define SCH_OK					01
#define SCH_FILE_NOT_EXISTS		02
#define SCH_LOAD_ERROR			03
#define SCH_GENERAL_ERROR		99

#define TRUE					1
#define FALSE					0

typedef int ERROR_TYPE;
typedef int BOOL_TYPE;

struct FILE_HEADER
{
    char id[3];         // c�digo identificador de arquivo "SCH"
    int quantity;       // quantidade de arquivos dentro do pacote
    int size;           // tamanho do arquivo
    int offset;         // posi��o onde come�a o conte�do dos arquivos
};

struct FILE_ITEM_HEADER
{
    char filename[MAX_FILENAME_SIZE];   // nome do arquivo
    int size;                           // tamanho do arquivo
    int compressed_size;                // tamanho do arquivo compactado
    int offset;                         // posi��o do arquivo
};

struct FILE_ITEM_DATA
{
    char* data;         // file data
};

struct FILE_HEADER* header = 0;
struct FILE_ITEM_HEADER** item_header = 0;
struct FILE_ITEM_HEADER** item_header_tmp = 0;
struct FILE_ITEM_DATA** item_data = 0;
struct FILE_ITEM_DATA** item_data_tmp = 0;

struct FILE_ITEM_HEADER item_header_new;
struct FILE_ITEM_DATA item_data_new;

int number_of_itens_header = 0;
int number_of_itens_data = 0;

char filename[MAX_FILENAME_SIZE];

// HEADER FUNCTIONS /////////////////////////////////////////////////////////////
void create_header()
{
    header = (struct FILE_HEADER*) malloc (sizeof(struct FILE_HEADER));
	memset(header, '\0', sizeof(struct FILE_HEADER));

    strcpy(header->id, FILE_HEADER_STRING);
    header->quantity = 0;
    header->size = 0;
    header->offset = 0;
}

void destroy_header()
{
    if(header != 0)
	{
		free(header);
		header = 0;
	}
}

// ITEM HEADER FUNCTIONS ///////////////////////////////////////////////////////
void free_item_header()
{
    int i = 0;

    for(i = 0; i < number_of_itens_header; i++)
    {
        if(item_header != 0 && item_header[i] != 0)
		{
	        free(item_header[i]);
			item_header[i] = 0;
		}
    }

    if(item_header != 0)
	{
	    free(item_header);
		item_header = 0;
	}
}

void free_item_header_tmp()
{
    int i = 0;

    // o array tmp vai sempre menos 1 em rela��o ao array normal
	for(i = 0; i < number_of_itens_header - 1; i++)
    {
        if(item_header_tmp != 0 && item_header_tmp[i] != 0)
		{
			free(item_header_tmp[i]);
			item_header_tmp[i] = 0;
		}
    }

    if(item_header_tmp != 0)
	{
		free(item_header_tmp);
		item_header_tmp = 0;
	}
}

void backup_item_header()
{
    int i = 0;

    // aloca a mem�ria do item header tmp
    if(number_of_itens_header > 0)
    {
		free_item_header_tmp();

        item_header_tmp = (struct FILE_ITEM_HEADER**) malloc (sizeof(struct FILE_ITEM_HEADER*) * number_of_itens_header);
		memset(item_header_tmp, '\0', sizeof(struct FILE_ITEM_HEADER*) * number_of_itens_header);

        for(i = 0; i < number_of_itens_header; i++)
        {
            item_header_tmp[i] = (struct FILE_ITEM_HEADER*) malloc (sizeof(struct FILE_ITEM_HEADER));
			memset(item_header_tmp[i], '\0', sizeof(struct FILE_ITEM_HEADER));
        }
    }

    // copia o item header para o item_header_tmp
    if(number_of_itens_header > 0)
    {
        for(i = 0; i < number_of_itens_header; i++)
        {
            strcpy(item_header_tmp[i]->filename, item_header[i]->filename);
            item_header_tmp[i]->size = item_header[i]->size;
            item_header_tmp[i]->compressed_size = item_header[i]->compressed_size;
            item_header_tmp[i]->offset = item_header[i]->offset;
        }
    }
}

void restore_item_header()
{
    int i = 0;

    // aloca a mem�ria do novo item header
    if(number_of_itens_header > 0)
    {
        item_header = (struct FILE_ITEM_HEADER**) malloc (sizeof(struct FILE_ITEM_HEADER*) * number_of_itens_header);
		memset(item_header, '\0', sizeof(struct FILE_ITEM_HEADER*) * number_of_itens_header);

        for(i = 0; i < number_of_itens_header; i++)
        {
            item_header[i] = (struct FILE_ITEM_HEADER*) malloc (sizeof(struct FILE_ITEM_HEADER));
			memset(item_header[i], '\0', sizeof(struct FILE_ITEM_HEADER));
        }
    }

    // copia o item header tmp para o item_header, deixando a �ltima c�lula em branco
    if(number_of_itens_header > 0)
    {
        for(i = 0; i < number_of_itens_header - 1; i++)
        {
            strcpy(item_header[i]->filename, item_header_tmp[i]->filename);
            item_header[i]->size = item_header_tmp[i]->size;
            item_header[i]->compressed_size = item_header_tmp[i]->compressed_size;
            item_header[i]->offset = item_header_tmp[i]->offset;
        }
    }
}

void create_item_header()
{
    // cria o novo array de item_header
    if(number_of_itens_header > 0)
    {
        backup_item_header();

        free_item_header();

        number_of_itens_header++;

        restore_item_header();
    }
    else
    {
        number_of_itens_header++;

        item_header = (struct FILE_ITEM_HEADER**) malloc (sizeof(struct FILE_ITEM_HEADER*) * number_of_itens_header);
		memset(item_header, '\0', sizeof(struct FILE_ITEM_HEADER*) * number_of_itens_header);

        item_header[0] = (struct FILE_ITEM_HEADER*) malloc (sizeof(struct FILE_ITEM_HEADER));
		memset(item_header[0], '\0', sizeof(struct FILE_ITEM_HEADER));
    }

    // preenche o novo item_header
    strcpy(item_header[number_of_itens_header - 1]->filename, item_header_new.filename);
    item_header[number_of_itens_header - 1]->size = item_header_new.size;
    item_header[number_of_itens_header - 1]->compressed_size = item_header_new.compressed_size;
    item_header[number_of_itens_header - 1]->offset = item_header_new.offset;
}

void destroy_item_header()
{
    if(number_of_itens_header > 0)
    {
        free_item_header();
        free_item_header_tmp();
		number_of_itens_header = 0;
    }
}

void remove_last_item_header()
{
	free_item_header_tmp();

	number_of_itens_header--;

	if(number_of_itens_header == 0)
	{
		destroy_item_header();
	}
	else
	{
		backup_item_header();

		restore_item_header();

		// preenche o ultimo item_header
		strcpy(item_header[number_of_itens_header - 1]->filename, item_header_tmp[number_of_itens_header - 1]->filename);
		item_header[number_of_itens_header - 1]->size = item_header_tmp[number_of_itens_header - 1]->size;
		item_header[number_of_itens_header - 1]->compressed_size = item_header_tmp[number_of_itens_header - 1]->compressed_size;
		item_header[number_of_itens_header - 1]->offset = item_header_tmp[number_of_itens_header - 1]->offset;
	}
}

// ITEM DATA FUNCTIONS ///////////////////////////////////////////////////
void free_item_data()
{
    int i = 0;

    for(i = 0; i < number_of_itens_data; i++)
    {
		if(item_data[i]->data != 0)
		{
			free(item_data[i]->data);
			item_data[i]->data = 0;
		}
		if(item_data[i] != 0)
		{
			free(item_data[i]);
			item_data[i] = 0;
		}
    }

	if(item_data != 0)
	{
		free(item_data);
		item_data = 0;
	}
}

void free_item_data_tmp()
{
    int i = 0;

    // o array tmp vai sempre menos 1 em rela��o ao array normal
    for(i = 0; i < number_of_itens_data - 1; i++)
    {
		if(item_data_tmp != 0 && item_data_tmp[i] != 0 && item_data_tmp[i]->data != 0)
		{
			free(item_data_tmp[i]->data);
			item_data_tmp[i]->data = 0;
		}
		if(item_data_tmp != 0 && item_data_tmp[i] != 0)
		{
			free(item_data_tmp[i]);
			item_data_tmp[i] = 0;
		}
    }

	if(item_data_tmp != 0)
	{
		free(item_data_tmp);
		item_data_tmp = 0;
	}
}

void backup_item_data()
{
    int i = 0;

    // aloca a mem�ria do item data tmp
    if(number_of_itens_data > 0)
    {
		free_item_data_tmp();

        item_data_tmp = (struct FILE_ITEM_DATA**) malloc (sizeof(struct FILE_ITEM_DATA*) * number_of_itens_data);
		memset(item_data_tmp, '\0', sizeof(struct FILE_ITEM_DATA*) * number_of_itens_data);

        for(i = 0; i < number_of_itens_data; i++)
        {
            item_data_tmp[i] = (struct FILE_ITEM_DATA*) malloc (sizeof(struct FILE_ITEM_DATA));
			memset(item_data_tmp[i], '\0', sizeof(struct FILE_ITEM_DATA));
			item_data_tmp[i]->data = (char*) malloc (item_header[i]->compressed_size);
			memset(item_data_tmp[i]->data, '\0', item_header[i]->compressed_size);
        }
    }

    // copia o item data para o item_data_tmp
    if(number_of_itens_data > 0)
    {
        for(i = 0; i < number_of_itens_data; i++)
        {
			memcpy(item_data_tmp[i]->data, item_data[i]->data, item_header[i]->compressed_size);
        }
    }
}

void restore_item_data()
{
    int i = 0;

    // aloca a mem�ria do novo item data
    if(number_of_itens_data > 0)
    {
        item_data = (struct FILE_ITEM_DATA**) malloc (sizeof(struct FILE_ITEM_DATA*) * number_of_itens_data);
		memset(item_data, '\0', sizeof(struct FILE_ITEM_DATA*) * number_of_itens_data);

        for(i = 0; i < number_of_itens_data; i++)
        {
            item_data[i] = (struct FILE_ITEM_DATA*) malloc (sizeof(struct FILE_ITEM_DATA));
			memset(item_data[i], '\0', sizeof(struct FILE_ITEM_DATA));
			item_data[i]->data = (char*) malloc (item_header[i]->compressed_size);
			memset(item_data[i]->data, '\0', item_header[i]->compressed_size);
        }
    }

    // copia o item data tmp para o item_data, deixando a �ltima c�lula em branco
    if(number_of_itens_data > 0)
    {
        for(i = 0; i < number_of_itens_data - 1; i++)
        {
			memcpy(item_data[i]->data, item_data_tmp[i]->data, item_header[i]->compressed_size);
        }
    }
}

void create_item_data()
{
    // cria o novo array de item_data
    if(number_of_itens_data > 0)
    {
        backup_item_data();

        free_item_data();

        number_of_itens_data++;

        restore_item_data();
    }
    else
    {
        number_of_itens_data++;

        item_data = (struct FILE_ITEM_DATA**) malloc (sizeof(struct FILE_ITEM_DATA*) * number_of_itens_data);
		memset(item_data, '\0', sizeof(struct FILE_ITEM_DATA*) * number_of_itens_data);

        item_data[0] = (struct FILE_ITEM_DATA*) malloc (sizeof(struct FILE_ITEM_DATA));
		memset(item_data[0], '\0', sizeof(struct FILE_ITEM_DATA));

		item_data[0]->data = (char*) malloc (item_header[number_of_itens_header - 1]->compressed_size);
		memset(item_data[0]->data, '\0', item_header[number_of_itens_header - 1]->compressed_size);
    }

    // preenche o novo item_data
	memcpy(item_data[number_of_itens_data - 1]->data, item_data_new.data, item_header[number_of_itens_header - 1]->compressed_size);
}

void destroy_item_data()
{
    if(number_of_itens_data > 0)
    {
        free_item_data();
        free_item_data_tmp();
		number_of_itens_data = 0;
    }
}

// FILE I/O FUNCTIONS ////////////////////////////////////////////////////
BOOL_TYPE load_item_data()
{
	int i = 0;

	FILE* file;

	file = fopen(item_header_new.filename, "rb");

	fseek(file, 0, SEEK_END);

	int file_size = ftell(file);

	// preenche o tamanho do arquivo na �ltima posi��o do array de headers
	item_header[number_of_itens_header - 1]->size = file_size;

	char* sourceBuff = (char*) malloc (file_size + 100);
	memset(sourceBuff, '\0', file_size + 100);

	fseek(file, 0, SEEK_SET);

	while(!feof(file))
	{
		char c = 0;

		fread(&c, 1, 1, file);

		sourceBuff[i] = c;

		i++;
	}

	// compacta os dados usando bzip2
	int size = file_size + file_size * 0.1 + 600;

	char* destBuff = (char*) malloc (size);
	memset(destBuff, '\0', size);

	unsigned int destLen = (unsigned int) size;
	unsigned int sourceLen = (unsigned int) file_size;

	int bz_return_var = BZ2_bzBuffToBuffCompress(destBuff, &destLen, sourceBuff, sourceLen, 1, 0, 0);

	if(bz_return_var != BZ_OK)
	{
        remove_last_item_header();

		return FALSE;
	}

	// conserta o header
	file_size = destLen;
	item_header[number_of_itens_header - 1]->compressed_size = file_size;

	// transfere os dados para o buffer de dados
	item_data_new.data = (char*) malloc (file_size);
	memset(item_data_new.data, '\0', file_size);
	memcpy(item_data_new.data, destBuff, file_size);

	free(sourceBuff);
	free(destBuff);

	fclose(file);

	return TRUE;
}

// FILE CALCULATIONS /////////////////////////////////////////////////////////////
void calculate_offset()
{
	int i = 0;
	int offset = 0;

	// soma o tamanho do header do arquivo SCH
	offset += sizeof(struct FILE_HEADER);

	// soma o tamanho do header de cada um dos arquivos do pacote
	for(i = 0; i < number_of_itens_header; i++)
	{
		offset += sizeof(struct FILE_ITEM_HEADER);
	}

	// preenche o offset no header que indica aonde come�am os dados
	header->offset = offset;

	// soma o tamanho dos dados de cada um dos arquivos
	for(i = 0; i < (number_of_itens_header - 1); i++)
	{
		offset += item_header[i]->compressed_size;
	}

	// preenche o offset do novo arquivo
	item_header[number_of_itens_header - 1]->offset = offset;
}

void calculate_filesize()
{
	int i = 0;
	int size = 0;

	// soma o tamanho do header do arquivo SCH
	size += sizeof(struct FILE_HEADER);

	// soma o tamanho do header de cada um dos arquivos do pacote
	for(i = 0; i < number_of_itens_header; i++)
	{
		size += sizeof(struct FILE_ITEM_HEADER);
	}

	// soma o tamanho dos dados de cada um dos arquivos
	for(i = 0; i < (number_of_itens_header); i++)
	{
		size += item_header[i]->compressed_size;
	}

	header->size = size;
	header->quantity = number_of_itens_header;
}

// FILE FUNCTIONS ////////////////////////////////////////////////////////
BOOL_TYPE check_file()
{
	if(fopen(item_header_new.filename, "r") == 0)
	{
		return FALSE;
	}

	return TRUE;
}

ERROR_TYPE create_file()
{
    if(check_file())
	{
		create_item_header();

		if(load_item_data())
		{
			create_item_data();

			calculate_offset();

			calculate_filesize();

			return SCH_OK;
		}
		else
		{
			return SCH_LOAD_ERROR;
		}
	}
	else
	{
		return SCH_FILE_NOT_EXISTS;
	}
}

void destroy_file()
{
	destroy_item_header();

	destroy_item_data();
}

void save_file()
{
	int i = 0;

	FILE* file;

	file = fopen(filename, "wb");

	// grava o header do arquivo
	fwrite(header, sizeof(struct FILE_HEADER), 1, file);

	// grava o array de headers de itens do pacote
	for(i = 0; i < number_of_itens_header; i++)
	{
		fwrite(item_header[i], sizeof(struct FILE_ITEM_HEADER), 1, file);
	}

	// grava o array de dados de itens do pacote
	for(i = 0; i < number_of_itens_data; i++)
	{
		fwrite(item_data[i]->data, item_header[i]->compressed_size, 1, file);
	}

	fclose(file);
}

void read_file()
{
	int i = 0;

	FILE* file;

	file = fopen(filename, "rb");

	// aloca mem�ria para o header
	header = (struct FILE_HEADER*) malloc (sizeof(struct FILE_HEADER));
	memset(header, '\0', sizeof(struct FILE_HEADER));

	// l� o header no arquivo
	fread(header, sizeof(struct FILE_HEADER), 1, file);

	// aloca mem�ria para os headers dos itens
	item_header = (struct FILE_ITEM_HEADER**) malloc (sizeof(struct FILE_ITEM_HEADER*) * header->quantity);
	memset(item_header, '\0', sizeof(struct FILE_ITEM_HEADER*) * header->quantity);

	for(i = 0; i < header->quantity; i++)
	{
		item_header[i] = (struct FILE_ITEM_HEADER*) malloc (sizeof(struct FILE_ITEM_HEADER));
		memset(item_header[i], '\0', sizeof(struct FILE_ITEM_HEADER));
	}

	// l� os headers dos itens
	for(i = 0; i < header->quantity; i++)
	{
		fread(item_header[i], sizeof(struct FILE_ITEM_HEADER), 1, file);
	}

	// aloca mem�ria para os dados dos itens
	item_data = (struct FILE_ITEM_DATA**) malloc (sizeof(struct FILE_ITEM_DATA*) * header->quantity);
	memset(item_data, '\0', sizeof(struct FILE_ITEM_DATA) * header->quantity);

	for(i = 0; i < header->quantity; i++)
	{
		item_data[i] = (struct FILE_ITEM_DATA*) malloc (sizeof(struct FILE_ITEM_DATA));
		memset(item_data[i], '\0', sizeof(struct FILE_ITEM_DATA));
	}

	// aloca mem�ria para os dados
	for(i = 0; i < header->quantity; i++)
	{
		item_data[i]->data = (char*) malloc (item_header[i]->compressed_size);
	}

	// l� os dados
	for(i = 0; i < header->quantity; i++)
	{
		fread(item_data[i]->data, sizeof(char), item_header[i]->compressed_size, file);
	}

	fclose(file);
}

BOOL_TYPE extract_file()
{
	int i = 0;

	for(i = 0; i < header->quantity; i++)
	{
		if(strcmp(item_header[i]->filename, filename) == 0)
		{
			FILE* file;

			file = fopen(item_header[i]->filename, "wb");

			// descompacta os dados usando bzip2
			char* dstBuffer = (char*) malloc (item_header[i]->size);
			char* srcBuffer = (char*) malloc (item_header[i]->compressed_size);

			unsigned int dstLen = item_header[i]->size;
			unsigned int srcLen = item_header[i]->compressed_size;

			memcpy(srcBuffer, item_data[i]->data, srcLen);

			int bz_return_var = BZ2_bzBuffToBuffDecompress(dstBuffer, &dstLen, srcBuffer, srcLen, 0, 0);

			// tratamento de erro
			if(bz_return_var != BZ_OK)
			{
				free(dstBuffer);
				free(srcBuffer);

				return FALSE;
			}

			// escreve o arquivo
			fwrite(dstBuffer, item_header[i]->size, 1, file);

			fclose(file);

			free(dstBuffer);
			free(srcBuffer);

			return TRUE;
		}
	}

	return FALSE;
}

// TELAS DAS OP��ES DE MENU //////////////////////////////////////////////
void screen_create_header_ok()
{
    system("cls");

    printf("Header criado com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_destroy_header_ok()
{
    system("cls");

    printf("Header destruido com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_insert_item()
{
    system("cls");

    printf("Insere Item");

    printf("\n\n");

    printf("Digite o nome do arquivo (max. 100): ");

    memset(&item_header_new, '\0', MAX_FILENAME_SIZE);

    scanf("%s", item_header_new.filename);

    item_header_new.size = 0;
    item_header_new.offset = 0;
}

void screen_insert_item_ok()
{
    system("cls");

    printf("Item incluido com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_insert_item_file_not_exists()
{
    system("cls");

    printf("Arquivo nao encontrado");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_insert_item_load_error()
{
    system("cls");

    printf("Erro ao carregar arquivo");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_destroy_item_header_ok()
{
    system("cls");

    printf("Itens destruidos com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_save_file()
{
    system("cls");

    printf("Gravar Arquivo");

    printf("\n\n");

	printf("Digite o nome do arquivo: ");

	scanf("%s", filename);
}

void screen_save_file_ok()
{
    system("cls");

    printf("Arquivo gravado com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_read_file()
{
    system("cls");

    printf("Ler Arquivo");

    printf("\n\n");

	printf("Digite o nome do arquivo: ");

	scanf("%s", filename);
}

void screen_read_file_ok()
{
    system("cls");

    printf("Arquivo carregado com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_extract_file()
{
    system("cls");

    printf("Extrai Arquivo");

    printf("\n\n");

	printf("Digite o nome do arquivo: ");

	scanf("%s", filename);
}

void screen_extract_file_ok()
{
    system("cls");

    printf("Arquivo extraido com sucesso");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_extract_file_error()
{
    system("cls");

    printf("Erro ao extrair arquivo");

    printf("\n\n");

    printf("Pressione uma tecla...");

    getch();
}

void screen_list_files()
{
    int i = 0;

	system("cls");

    printf("Lista de Arquivos");

    printf("\n\n");

	if(header != 0)
	{
        for(i = 0; i < header->quantity; i++)
        {
            printf("%s\n", item_header[i]->filename);
        }
	}
	else
	{
	    printf("Nenhum arquivo para listar\n");
	}

    printf("\n");

	printf("Pressione uma tecla...");

    getch();
}

// MENU //////////////////////////////////////////////////////////////////
BOOL_TYPE execute_menu(int option)
{
	ERROR_TYPE error;

	switch(option)
    {
        case '0':
			destroy_header();
			destroy_item_header();
			destroy_item_data();
            return FALSE;
            break;
        case '1':
            create_header();
            screen_create_header_ok();
            break;
        case '2':
            destroy_header();
            screen_destroy_header_ok();
            break;
        case '3':
            screen_insert_item();

			error = create_file();

			if(error == SCH_OK)
			{
				screen_insert_item_ok();
			}
			else if(error == SCH_FILE_NOT_EXISTS)
			{
				screen_insert_item_file_not_exists();
			}
			else if(error == SCH_LOAD_ERROR)
			{
				screen_insert_item_load_error();
			}

			break;
        case '4':
            destroy_item_header();
			destroy_item_data();
            screen_destroy_item_header_ok();
			break;
		case '5':
			screen_save_file();
			save_file();
			screen_save_file_ok();
			break;
		case '6':
			screen_read_file();
			read_file();
			screen_read_file_ok();
			break;
		case '7':
			screen_extract_file();

			if(extract_file())
			{
				screen_extract_file_ok();
			}
			else
			{
				screen_extract_file_error();
			}

			break;
		case '8':
			screen_list_files();
			break;
        default:
            break;
    }

    return TRUE;
}

// MAIN //////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
    int option = -1;
    BOOL_TYPE run = TRUE;

    while(run)
    {
        system("cls");

        printf("Empacotador de Arquivos\n");

        printf("\n");

        printf("Escolha uma das opcoes abaixo:\n");

        printf("\n");

        printf("1 - Cria Header\n");

        printf("2 - Destroi Header\n");

        printf("3 - Insere Item\n");

        printf("4 - Destroi Todos os Itens\n");

        printf("5 - Grava Arquivo\n");

        printf("6 - Carrega Arquivo\n");

        printf("7 - Extrai Arquivo\n");

        printf("8 - Lista Arquivos\n");

        printf("\n");

        printf("0 - Finalizar\n");

        printf("\n");

        printf("Opcao: ");

        option = getch();

        run = execute_menu(option);
    }

    return 0;
}
