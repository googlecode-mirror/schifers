/******************************************************************
 *
 *  libschpck - Schifer's Packing Library
 *
 *  Biblioteca de leitura de arquivos empacotados
 *
 *  Desenvolvido por Bruno Schifer Bernardi
 *
 *  Pertence a SCHIFER TECNOLOGIA LTDA - 2008
 *
 ******************************************************************/

#include "main.h"

// carrega um arquivo em mem�ria
ERROR_TYPE DLL_EXPORT loadFile(char* filename, FILE_HEADER* header, FILE_ITEM_HEADER*** item_header, FILE_ITEM_DATA*** item_data, int* item_header_len, int* item_data_len)
{
	int i = 0;

	FILE* file;

    // abre o arquivo ou retorna erro caso ele n�o exista
	file = fopen(filename, "rb");
	if(!file)
	{
	    return SCH_FILE_NOT_EXISTS;
	}

	memset(header, '\0', sizeof(struct FILE_HEADER));

	// l� o header no arquivo
	fread(header, sizeof(struct FILE_HEADER), 1, file);

	// aloca mem�ria para os headers dos itens
	*item_header = (struct FILE_ITEM_HEADER**) malloc (sizeof(struct FILE_ITEM_HEADER*) * header->quantity);
	memset(*item_header, '\0', sizeof(struct FILE_ITEM_HEADER*) * header->quantity);

	for(i = 0; i < header->quantity; i++)
	{
		item_header[0][i] = (struct FILE_ITEM_HEADER*) malloc (sizeof(struct FILE_ITEM_HEADER));
		memset(item_header[0][i], '\0', sizeof(struct FILE_ITEM_HEADER));
	}

	// l� os headers dos itens
	for(i = 0; i < header->quantity; i++)
	{
		fread(item_header[0][i], sizeof(struct FILE_ITEM_HEADER), 1, file);
	}

	// aloca mem�ria para os dados dos itens
	*item_data = (struct FILE_ITEM_DATA**) malloc (sizeof(struct FILE_ITEM_DATA*) * header->quantity);
	memset(*item_data, '\0', sizeof(struct FILE_ITEM_DATA) * header->quantity);

	for(i = 0; i < header->quantity; i++)
	{
		item_data[0][i] = (struct FILE_ITEM_DATA*) malloc (sizeof(struct FILE_ITEM_DATA));
		memset(item_data[0][i], '\0', sizeof(struct FILE_ITEM_DATA));
	}

	// aloca mem�ria para os dados
	for(i = 0; i < header->quantity; i++)
	{
		item_data[0][i]->data = (char*) malloc (item_header[0][i]->compressed_size);
	}

	// l� os dados
	for(i = 0; i < header->quantity; i++)
	{
		fread(item_data[0][i]->data, sizeof(char), item_header[0][i]->compressed_size, file);
	}

	fclose(file);

    return SCH_OK;
}

ERROR_TYPE DLL_EXPORT extractFile(char* filename, FILE_HEADER* header, FILE_ITEM_HEADER** item_header, FILE_ITEM_DATA** item_data, char** dstBuffer, unsigned int* dstLen)
{
	int i = 0;

	for(i = 0; i < header->quantity; i++)
	{
		if(strcmp(item_header[i]->filename, filename) == 0)
		{
			// descompacta os dados usando bzip2
			*dstBuffer = (char*) malloc (item_header[i]->size);
			char* srcBuffer = (char*) malloc (item_header[i]->compressed_size);

			*dstLen = item_header[i]->size;
			unsigned int srcLen = item_header[i]->compressed_size;

			memcpy(srcBuffer, item_data[i]->data, srcLen);

			int bz_return_var = BZ2_bzBuffToBuffDecompress(*dstBuffer, dstLen, srcBuffer, srcLen, 0, 0);

			// tratamento de erro
			if(bz_return_var != BZ_OK)
			{
				free(dstBuffer);
				free(srcBuffer);

				return SCH_DECOMPRESS_ERROR;
			}

			free(srcBuffer);
		}
	}

	return SCH_OK;
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // attach to process
            // return FALSE to fail DLL load
            break;

        case DLL_PROCESS_DETACH:
            // detach from process
            break;

        case DLL_THREAD_ATTACH:
            // attach to thread
            break;

        case DLL_THREAD_DETACH:
            // detach from thread
            break;
    }
    return TRUE; // succesful
}
