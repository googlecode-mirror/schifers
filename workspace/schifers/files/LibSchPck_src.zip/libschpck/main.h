/******************************************************************
 *
 *  libschpck - Schifer's Packing Library
 *
 *  Biblioteca de leitura de arquivos empacotados
 *
 *  Desenvolvido por Bruno Schifer Bernardi
 *
 *  Pertence a SCHIFER TECNOLOGIA LTDA - 2008
 *
 ******************************************************************/

#ifndef __MAIN_H__
#define __MAIN_H__

#include <windows.h>

#include <stdio.h>

#include "bzlib.h"

/*  To use this exported function of dll, include this header
 *  in your project.
 */

#ifdef BUILD_DLL
    #define DLL_EXPORT __declspec(dllexport)
#else
    #define DLL_EXPORT __declspec(dllimport)
#endif


#ifdef __cplusplus
extern "C"
{
#endif

#define FILE_HEADER_STRING "SCH"
#define MAX_FILENAME_SIZE 100

#define SCH_OK					01
#define SCH_FILE_NOT_EXISTS		02
#define SCH_LOAD_ERROR			03
#define SCH_MALLOC_ERROR        04
#define SCH_DECOMPRESS_ERROR    05
#define SCH_GENERAL_ERROR		99

#define TRUE					1
#define FALSE					0

typedef int ERROR_TYPE;
typedef int BOOL_TYPE;

struct FILE_HEADER
{
    char id[3];         // c�digo identificador de arquivo "SCH"
    int quantity;       // quantidade de arquivos dentro do pacote
    int size;           // tamanho do arquivo
    int offset;         // posi��o onde come�a o conte�do dos arquivos
};

struct FILE_ITEM_HEADER
{
    char filename[MAX_FILENAME_SIZE];   // nome do arquivo
    int size;                           // tamanho do arquivo
    int compressed_size;                // tamanho do arquivo compactado
    int offset;                         // posi��o do arquivo
};

struct FILE_ITEM_DATA
{
    char* data;         // file data
};

ERROR_TYPE DLL_EXPORT loadFile(char* filename, FILE_HEADER* header, FILE_ITEM_HEADER*** item_header, FILE_ITEM_DATA*** item_data, int* item_header_len, int* item_data_len);

ERROR_TYPE DLL_EXPORT extractFile(char* filename, FILE_HEADER* header, FILE_ITEM_HEADER** item_header, FILE_ITEM_DATA** item_data, char** dstBuffer, unsigned int* dstLen);

#ifdef __cplusplus
}
#endif

#endif // __MAIN_H__
