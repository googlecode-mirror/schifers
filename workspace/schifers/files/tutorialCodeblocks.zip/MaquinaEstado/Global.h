#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h> 

#include "Maquina.h"
#include "Estado.h"
#include "Estados.h"
